# 命令与征服-红色警戒-win10-补丁<br>
# Command-and-Conquer-Red-Alert-II-win10-patch<br>
* 这个补丁，可以让你在windows 10中完美的运行《命令与征服·红色警戒2+尤里的复仇资料片》，<br>
* This patch allows you to run "Command & Conquer, Red Alert 2 + Yuri's Revenge" on Windows 10.<br>
* 在使用之前，你应该遵守我的规则：你可以下载和使用并且将这个补丁通过 [ 这个超级链接 ](https://github.com/873578156/Command-and-Conquer-Red-Alert-II-win10-patch)引用或分享给其他人，但是你不可以做有关于重新打包，转载、复制、盗窃的举动。<br>
* Before using it, you should follow my rules: You can download and user it.You can pass this patch [this hyperlink](https://github.com/873578156/Command-and-Conquer-Red-Alert-II-win10-patch) Quote or share with others, but you can't do anything about repackaging, reprinting, copying, or stealing. <br>
* 本补丁中的`ddraw.dll`和`wsock32.dll`均来自开源社区。<br>
* Both `ddraw.dll` and `wsock32.dll` in this patch are from the open source community. <br>
* 本补丁免费提供，如果你看到有任何商业行为，包括比如淘宝店铺在内的一些商业行为，请向我举报，谢谢。 <br>
* This patch is available free of charge. If you see any commercial activities, including those in Taobao stores, please report them to me. Thank you. <br>
* 补丁使用方法：<br>
* How to use the patch:<br>
        1.本补丁在windows 8和windows 8.1中也可以用，不仅仅局限于windows 10.<br>
        1. This patch can also be used in windows 8 and windows 8.1, not only limited to windows 10.<br>
                2.系统的缩放必须是：`100%`。设置方法：①点击`开始`按钮②进入`设置`功能③选择`系统`选项④选择`显示`选项⑤，在`缩放与布局中`找到`更改文本、应用等项目的大小`，将其选择为`100%`，然后`注销`或`重启`你的电脑。<br>
                2. The scaling of the system must be: `100%`. Setting method: 1 Click the `Start` button 2 Enter `Set` function 3 Select `System` option 4 Select `Show` option 5, `Scaling and layout ` find `Change the size of text, applications, etc.`, Select `100%`, then `log out` or `restart` your computer. <br>
        3.现在打开你的游戏目录，如果你之前改动了文件或者其他，最好可以重新下载。<br>
        3. Now open your game directory. If you have changed files or something else before, it's best to download it again. <br>
        4.复制补丁中的所有文件到你的游戏目录，他可能会提示被覆盖，请选择`是`。<br>
        4. Copy all the files in the patch to your game directory. He may be prompted to be overwritten. Select `Yes`. <br>
                5.如果你使用的是origin客户端，在你下载之后它会为你自动设置`Ra2.exe`，`RA2MD.exe`，`YURI.exe`的`兼容性`选项，请在文件`属性`，`兼容性`中取消它们的任何兼容性选项。<br>
                5. If you are using origin client, it will automatically set `Ra2.exe`, `RA2MD.exe`, `YURI.exe`` compatibility` options for you after downloading. `, `Compatibility` remove any of their compatibility options. `<br>
        6.如果你的分辨率不是`1920*1080`，请在`ra2.ini`和`ra2md.ini`中更改。<br>
        6. If your resolution is not `1920*1080`, change it in `ra2.ini` and `ra2md.ini`. <br>
        7.现在打开你的游戏，去享受它把。<br>
        7. Open your game now and enjoy it. <br>
        8.[点击这个链接，加入QQ群聊：五月幻想048—玩游戏，让我们一起交流红色警戒。](https://jq.qq.com/?_wv=1027&k=5HiqSxF)<br>
        8.[Click this link to join the QQ group chat: May Fantasy 048 - Play the game, let us communicate red alert together. ](https://jq.qq.com/?_wv=1027&k=5HiqSxF)<br>

PS.如果你需要中文语言，你可以去除game.fnt，ra2.csf，ra2md.csf的.bak.S-Chinese后缀。只需重命名即可。 <br>
PS..win后缀的文件是用来在origin平台使用窗口化模式进行游戏，如果需要，删除.win后缀即可。 <br>
PS.The .win suffix file is used to play games on the origin platform using the windowing mode. If needed, the .win suffix can be removed. <br>
